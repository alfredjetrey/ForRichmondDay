﻿$(document).ready(function () {
    $.getJSON(
        'https://raw.githubusercontent.com/RichmondDay/public/master/test_vehicle_inventory_data.json',
        function (data) {
            var htmlCon = [];
            $.each(data, function (i, item) {
               var htmlData = '<div class="col-md-6 col-sm-6 col-xs-12 clearfix">' +
                    '<div class="json-content-parent">' +
                    '<div class="json-content-child">' +
                    '<div><a class="name serif" href="#">' + data[i].Name +'</a></div>' +
                    '<div class="price serif">' + data[i].Price  +'</div>' +
                    '<div class="img"><img class="width-100" src="/' + data[i].Photo +'"/></div>' +
                    '<div class="details">' +
                    '<div class="retail">' +
                    '<div class="float-left serif">Retailer:</div>' +
                    '<div class="data-result ">' + data[i].Retailer +'</div>' +
                                '</div>'+
                    '<div class="kilometer">' +
                                '<div class="float-left serif">Kilometres:</div>' +
                    '<div class="data-result">' + data[i].Kilometres +'</div>' +
                                '</div>'+
                                '<div class="trans">' +
                                '<div class="float-left serif">Transmission:</div>' +
                                    '<div class="data-result">' + data[i].Transmission +'</div>' +
                                '</div>'+
                                '<div class="exterior">'+
                                    '<div class="float-left">Exterior:</div>' +
                                    '<div class="data-result">' + data[i].Exterior +'</div>' +
                                '</div>'+
                                '<div class="interior">'+
                                        '<div class="float-left serif">Interior:</div>' +
                                    '<div class="data-result">' + data[i].Interior +'</div>' +
                                    '</div>' +
                                    '<div class="vin">' +
                                            '<div class="float-left serif">VIN:</div>' +
                                    '<div class="data-result">' + data[i].VIN +'</div>' +
                                    '</div>' +
                                    '<div class="drive">' +
                                                '<div class="float-left serif">DriveTrain:</div>' +
                                    '<div class="data-result">' + data[i].DriveTrain +'</div>' +
                                    '</div>' +
                                    '</div>' +
                                    '<div class="json-btn">' +
                                    '<div class="btn-divider width-100">' +
                                    '<button class="btn btn-primary btn-json">VIEW DETAILS</button>' +
                                    '</div>' +
                                    '<div class="btn-divider  width-100">' +
                                    '<button class="btn btn-primary btn-json">BOOK A TEST DRIVE</button>' +
                                    '</div>' +
                                    '</div>' +
                                    '</div>' +
                                    '</div>' +
                    '</div>';

                                htmlCon.push(htmlData)
            })

            $('#CarDetails .row').empty();
            $('#CarDetails .row').html(htmlCon);
        }
    );

    $('.play-Icon').on('click', function (ev) {

        var source = 'https://www.youtube.com/watch?v=Ldjmb15Jsx0';
        $('.static-image').css('display', 'none')
        $('.videoWrapper').css('display', 'block');

            player = new YT.Player('embedded-video', {
                height: '340',
                width: '560',
                videoId: 'Ldjmb15Jsx0', source,
                events: {
                    'onReady': onPlayerReady,
                    'onStateChange': onPlayerStateChange
                }
            });          
    });

    // autoplay video
    function onPlayerReady(event) {
        event.target.playVideo(event);
    }

    // when video ends
    function onPlayerStateChange(event) {
        if (event.data === 0) {
            $('.static-image').css('display', 'block');
            $('.videoWrapper').css('display', 'none');
            $('.videoWrapper').empty();
            $('.videoWrapper').append('<div id="embedded-video"></div>');
        }
    }

    //BACK END TEST SECTION
    $('body').on('click', '.user-table .edit-user', function () {
        var parent = $(this).closest('td').closest('tr')
        var id = $(this).attr('data-id');
        $.ajax({
            url: "/Home/EditUser",
            type: "GET",
            data: "id=" + id,
            success: function (data) {               
                parent.find('td:nth(1)').empty().html(' <input class="form-control"  type="text" value="' + data.FirstName +'" />');
                parent.find('td:nth(2)').empty().html(' <input class="form-control"  type="text" value="' + data.LastName + '" />');
                parent.find('td:nth(3)').empty().html(' <input class="form-control"  type="text" value="' + data.Email + '" />');
                parent.find('td:nth(4)').find('a').attr('disabled', false)
            },
            error: function (result) {
                alert("Failed");
            }
        });
    })

    $('body').on('click', '.save-edit-user', function () {
        var parent = $(this).closest('td').closest('tr')
        var id = $(this).attr('data-id')
        var first_Name = parent.find('td:nth(1)').find('input').val();
        var last_Name = parent.find('td:nth(2)').find('input').val();
        var email = parent.find('td:nth(3)').find('input').val();
        var user = {}
        user.Id = id
        user.FirstName = first_Name
        user.LastName = last_Name
        user.Email = email

        if (validateEmail(email)) {     
            $.ajax({
                url: "/Home/EditUser",
                type: "POST",
                data: { user: user },
                success: function (data) {
                    parent.find('td:nth(1)').empty().html(data.FirstName);
                    parent.find('td:nth(2)').empty().html(data.LastName);
                    parent.find('td:nth(3)').empty().html(data.Email);
                    parent.find('td:nth(4)').find('a').attr('disabled', true)        
                },
                error: function (result) {
                    alert("Failed");
                }
            });

        } else {
            $.alert({
                title: "ALERT",
                content: "please enter the correct email address",
                buttons: {
                    close: {
                        action: function () {
                        }
                    }
                }
            })
        }
    })

    $('body').on('click', '#ShowCreateNewUser', function () {
        $('.paging_simple_numbers span').find('a:last-child').click();
        $(this).attr('disabled', true)
        AddRow()
    })

    $('body').on('click', '.add-new-user', function () {
        var parent = $(this).closest('td').closest('tr')
        var first_Name = parent.find('td:nth(1)').find('input').val();
        var last_Name = parent.find('td:nth(2)').find('input').val();
        var email = parent.find('td:nth(3)').find('input').val();
        var user = {}
        user.FirstName = first_Name
        user.LastName = last_Name
        user.Email = email
        if (validateEmail(email)) {
            $.ajax({
                url: "/Home/CreateUser",
                type: "POST",
                data: { user: user },
                success: function (data) {                     
                    InstantiateDatatable()
                    $('#ShowCreateNewUser').attr('disabled', false);                 
                },
                error: function (result) {
                    alert("Failed");
                }
            });

        } else {
            $.alert({
                title: "ALERT",
                content: "please enter the correct email address",
                buttons: {
                    close: {
                        action: function () {
                        }
                    }
                }
            })
        }
    })


    $('body').on('click', '.delete-user', function () {
        var id = $(this).attr('data-id')
        $.alert({
            title: "ALERT",
            content: "are you sure you want to delete user?",
            buttons: {
                yes: {
                    action: function () {
                        $.ajax({
                            url: "/Home/DeleteUser",
                            type: "POST",
                            data: "id=" + id,
                            success: function (data) {                          
                                if (data === 1){
                                    InstantiateDatatable()
                                } else {
                                    $.alert({
                                        title: "ALERT",
                                        content: "Cannot Delete User",
                                        buttons: {
                                            close: {
                                                action: function () {
                                                }
                                            }
                                        }
                                    })
                                }                              
                            },
                            error: function (result) {
                                alert("Failed");
                            }
                        });
                    }
                }
            }
        })
    })

    function validateEmail(email) {
        var re = /\S+@\S+\.\S+/;
        var result = re.test(email);
        return result;
    }

    function AddRow() {
        var addNewRow = '<tr role="row">' +
            '<td class="sorting_1"></td>' +
            '<td><input class="form-control" type="text"  /></td>' +
            '<td><input class="form-control" type="text" /></td>' +
            '<td><input class="form-control" type="text"  /></td>' +
            '<td><a class="btn btn-primary glyphicon glyphicon-plus add-new-user"></a></td>' +
            '<td></td>' +
            '<td></td>' +
            '</tr>';
      $('.user-table').append(addNewRow) 
    }


    function InstantiateDatatable() {
        setTimeout(function () {
            $('.user-table').DataTable().destroy();
            $(".user-table").DataTable({
                ajax: {
                    url: "/Home/UserRecord",
                    type: "GET",
                    dataSrc: ""
                },
                columns: [{
                    data: "Id",
                    render: function (data, type, users) {
                        return users.Id;
                    }
                },
                {
                    data: "FirstName",
                    render: function (data, type, users) {
                        return users.FirstName;
                    }
                },
                {
                    data: "LastName",
                    render: function (data, type, users) {
                        return users.LastName;
                    }
                },
                {
                    data: "Email",
                    render: function (data, type, users) {
                        return users.Email;
                    }
                },
                {
                    data: "Id",
                    render: function (data, type, users) {
                        return "<a class='btn btn-primary glyphicon glyphicon-save save-edit-user' data-id='" + users.Id + "' disabled></a>";
                    }
                },
                {
                    data: "Id",
                    render: function (data, type, users) {
                        return "<a class='btn btn-primary glyphicon glyphicon-pencil edit-user' data-id='" + users.Id + "' ></a>";
                    }
                },
                {
                    data: "Id",
                    render: function (data, type, users) {
                        return "<a class='btn btn-danger glyphicon glyphicon-remove-sign delete-user' data-id='" + users.Id + "' ></a>";
                    }
                }

                ]
            })
        }, 100);
    }



})