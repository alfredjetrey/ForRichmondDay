﻿using LinqToExcel;
using Richmond_Test.Models;
using Richmond_Test.ViewModel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Richmond_Test.Controllers
{
    public class HomeController : Controller
    {
        private AppContext _context;

        public HomeController()
        {
            _context = new AppContext();
        }

        // GET: Home
        public ActionResult Index()
        {
           return View();
        }

        public void LoadInitialData() {
            //string directory = Directory.GetCurrentDirectory().Replace("\\bin\\Debug", "");
            string excelFile = Path.GetFullPath("C:\\Users\\Alfred\\Desktop\\files\\test\\CodeFile\\Richmond_Test\\Richmond_Test\\File\\MOCK_DATA.xlsx");

            //Load Info
            var excel = new ExcelQueryFactory(excelFile);
            excel.AddMapping("FirstName", "first_name");
            excel.AddMapping("LastName", "last_name");
            excel.AddMapping("Email", "email");

            var users = (from x in excel.Worksheet<User>("data") select x).ToList();   
            foreach (var user in users)
            {
                var checkForDuplicate = _context.Users.Where(x => x.Email == user.Email).FirstOrDefault();
                if (checkForDuplicate == null)
                {
                    _context.Users.Add(user);
                    _context.SaveChanges();
                }
                else {
                    var duplicate = user;
                }                    
            }
        }

        public JsonResult UserRecord()
        {
            var users = _context.Users.ToList();            
            return Json(users, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public JsonResult EditUser(int id) {
            UserVM userVM = new UserVM();
            var user = _context.Users.Where(x=>x.Id == id).FirstOrDefault();
            if (user != null) {
                userVM.Id = user.Id;
                userVM.FirstName = user.FirstName;
                userVM.LastName = user.LastName;
                userVM.Email = user.Email;
            }
            return Json(userVM, JsonRequestBehavior.AllowGet);
            //return PartialView("~/Views/Home/Users/_EditUser.cshtml", userVM);                
        }

        [HttpPost]
        public ActionResult EditUser(UserVM user)
        {
            var updateUser = _context.Users.Where(x => x.Id == user.Id).FirstOrDefault();
            if (ModelState.IsValid) {             
                if (user != null)
                {
                    updateUser.FirstName = user.FirstName;
                    updateUser.LastName = user.LastName;
                    updateUser.Email = user.Email;
                    _context.SaveChanges();
                    updateUser = _context.Users.Where(x => x.Id == user.Id).FirstOrDefault();
                }
            }            
            return Json(updateUser, JsonRequestBehavior.AllowGet);
        }

        public JsonResult CreateUser(UserVM user)
        {

            int NewUserId = 0;
            User savedUser = new User();
            if (ModelState.IsValid)
            {
                if (user != null)
                {
                    User newUser = new User();
                    newUser.FirstName = user.FirstName;
                    newUser.LastName = user.LastName;
                    newUser.Email = user.Email;
                    _context.Users.Add(newUser);
                    _context.SaveChanges();

                    NewUserId = newUser.Id;
                    savedUser.Id = NewUserId;
                    savedUser.FirstName = newUser.FirstName;
                    savedUser.LastName = newUser.LastName;
                    savedUser.Email = newUser.Email;
                }
            }

            return Json(savedUser, JsonRequestBehavior.AllowGet);
        }

        public JsonResult DeleteUser(int id)
        {
            var user = _context.Users.Where(x => x.Id == id).FirstOrDefault();
            int result = 0;
            if (user != null) {
                _context.Users.Remove(user);
                _context.SaveChanges();
                result = 1;
            }          
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        public ActionResult BackEnd() {
            return View();
        }


        public ActionResult FrontEnd() {
            return View();
        }
    }
}