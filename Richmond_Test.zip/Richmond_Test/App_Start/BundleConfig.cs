﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Optimization;

namespace Richmond_Test.App_Start
{
    public class BundleConfig
    {
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
                        "~/Scripts/jquery-{version}.js",
                             "~/Scripts/jquery-ui.js",
                               "~/Scripts/jquery-confirm.js",
                         "~/Scripts/jquery.validate*",
                        "~/Scripts/jquery.validate.unobtrusive.js",
                        "~/Scripts/jquery.dataTables.js",
                        "~/Scripts/Site.js"));


            bundles.Add(new ScriptBundle("~/bundles/bootstrap").Include(
                      "~/Scripts/bootstrap.js"));

            bundles.Add(new StyleBundle("~/Content/css").Include(
                      "~/Content/bootstrap.css",
                             "~/Content/jquery-ui.css",
                      "~/Content/jquery.dataTables.css",
                       "~/Content/jquery-confirm.css",
                      "~/Content/Site.css"));
        }
    }
}